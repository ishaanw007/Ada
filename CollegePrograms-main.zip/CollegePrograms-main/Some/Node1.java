package Some;

//Object of Edge
public class Node1 {
	// Stores destination vertex in adjacency list 
    int dest; 

    // Stores weight of a vertex in the adjacency list 
    int weight; 

    // Constructor 
    Node1(int a, int b) 
    { 
        dest = a; 
        weight = b; 
    }
}
