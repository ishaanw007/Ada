package Some;

import java.util.Comparator;

public class Node{
	// class to represent a node in PriorityQueue 
    // Stores a vertex and its corresponding 
    // key value 
        int vertex; 
        int key; 
}
